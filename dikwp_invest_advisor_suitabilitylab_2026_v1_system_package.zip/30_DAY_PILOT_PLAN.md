# 30-Day Pilot Plan

## Week 1: Boundary and templates
Confirm no trading/no product sales, investor data minimization, product universe, risk questionnaire, disclosure and advisor roles.

## Week 2: Suitability and evidence
Run 20 synthetic or consented cases, build Financial Evidence Ledger, test incomplete/inconsistent/imprecise inputs.

## Week 3: Product due diligence and AI governance
Add product document review, fee/liquidity/conflict checklist, AI Use Log and human review ticket.

## Week 4: Advisor workflow and audit
Run advisor/compliance review, export Investment Passport, review complaints and update templates.

## Acceptance criteria
Zero automated transaction. Zero yield promise. 100% specific product discussion backed by product documents. 100% high-risk product blocked without human review.
