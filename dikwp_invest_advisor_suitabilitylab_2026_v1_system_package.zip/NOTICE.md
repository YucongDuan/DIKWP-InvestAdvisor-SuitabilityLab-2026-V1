# NOTICE

DIKWP InvestAdvisor SuitabilityLab 2026 V1 is a synthetic-data reference implementation for investment education, suitability process design, advisor workflow demonstration, and GitHub demonstration.

Attribution: Yucong Duan / DIKWP ecosystem reference implementation.

This software does not provide investment advice, brokerage, fund sales, portfolio management, automated trading, tax advice or legal advice.
