# Governance and Safety Boundary

## Prohibited uses
- recommending specific securities, funds or trading times without licensed advisor review
- automatic buy/sell/rebalance/subscribe/redeem instructions
- yield guarantees or implicit promises
- investment advice based on rumours, insider information, unverified AI output or marketing materials alone
- collecting brokerage passwords, SMS codes, bank cards or API keys
- bypassing investor suitability and risk disclosure
- hiding fees, conflicts of interest or liquidity limits

## Required controls
- investor purpose and constraints
- risk capacity, risk tolerance, liquidity and knowledge checks
- evidence ledger and product-document source tracking
- product risk-rating and suitability matching
- fee, liquidity, concentration and conflict review
- AI output human verification
- human advisor/compliance review ticket
- client explanation and record keeping

## Kill conditions
Stop and downgrade to education-only if client information is incomplete, risk and return expectations conflict, product documents are missing, AI gives unsupported claims, product risk exceeds client grade, or a high-impact action is requested without qualified human review.
