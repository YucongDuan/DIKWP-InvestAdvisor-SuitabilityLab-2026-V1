# Sources

- China Securities Regulatory Commission: Securities and futures investor suitability rules.
- China Securities Regulatory Commission / SAC: Securities investment advisory and investment consulting rules, including reasonable basis, qualified personnel, internal control and compliance requirements.
- IOSCO: AI/ML use by market intermediaries and asset managers; governance, controls, testing, monitoring and disclosure expectations.
- NIST AI Risk Management Framework 1.0: govern, map, measure and manage AI risks.

Always verify the latest rules in the applicable jurisdiction before real use.
