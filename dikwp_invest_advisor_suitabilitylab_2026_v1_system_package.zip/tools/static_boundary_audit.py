#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r'order_api', 'trading API'),(r'place_order', 'order placement'),(r'api_key', 'API key'),(r'localStorage', 'browser storage'),(r'fetch\(', 'network fetch'),(r'XMLHttpRequest', 'network xhr'),(r'eval\(', 'dynamic eval'),(r'exec\(', 'dynamic exec')]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json','README.md','GOVERNANCE.md','NOTICE.md'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pattern,meaning in PATTERNS:
            if re.search(pattern,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning,'pattern':pattern})
    result={'package':'DIKWP InvestAdvisor SuitabilityLab 2026 V1','requires_human_review':True,'findings':findings,'note':'String matches require human review. The reference package includes no trading connector, no account storage and no live data/network requirement.'}
    (ROOT/'static_boundary_audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
