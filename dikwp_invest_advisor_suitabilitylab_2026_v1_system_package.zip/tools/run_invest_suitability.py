#!/usr/bin/env python3
"""Offline CLI for DIKWP InvestAdvisor SuitabilityLab 2026 V1."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime,timezone

def classify(inv):
    cap=0
    cap+=25 if inv.get('horizon_years',0)>=5 else 18 if inv.get('horizon_years',0)>=3 else 10
    cap+=20 if inv.get('emergency_months',0)>=6 else 10 if inv.get('emergency_months',0)>=3 else 0
    cap+=15 if inv.get('debt_ratio',100)<=30 else 8 if inv.get('debt_ratio',100)<=50 else 0
    cap+=15 if inv.get('investable_assets',0)/max(inv.get('annual_income',1),1)>=2 else 10 if inv.get('investable_assets',0)/max(inv.get('annual_income',1),1)>=1 else 5
    tol=min(100,inv.get('loss_tolerance',0)*4)
    score=round(cap*.45+tol*.35+20)
    grade='C1' if score<35 else 'C2' if score<50 else 'C3' if score<68 else 'C4' if score<82 else 'C5'
    return score,grade

def main():
    ap=argparse.ArgumentParser();ap.add_argument('profile',type=Path);ap.add_argument('--out',type=Path,default=Path('outputs'));args=ap.parse_args()
    inv=json.loads(args.profile.read_text(encoding='utf-8'))
    score,grade=classify(inv)
    report={'version':'DIKWP InvestAdvisor SuitabilityLab 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'investor':inv,'suitability_precheck':{'score':score,'grade':grade},'boundaries':{'investmentAdvice':False,'trading':False,'yieldPromise':False,'humanLicensedReviewRequired':True},'next_steps':['verify investor data','complete risk questionnaire','review product documents','run stress test','obtain human advisor/compliance review']}
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/f"{inv.get('id','investor')}_investment_passport.json"
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP InvestAdvisor SuitabilityLab 2026 V1')
    print('Grade:',grade,'Score:',score)
    print('Output:',target)
    print('Boundary: discussion draft only; no investment advice, no trading.')
if __name__=='__main__':main()
